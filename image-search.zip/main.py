"""
Image Search Service
====================
FastAPI application that:
  - Pre-loads OpenAI CLIP (ViT-B-32, float16) at startup.
  - Pre-computes and caches all tag vocabulary embeddings at startup.
  - Starts a background indexing queue worker at startup.
  - Provides POST /products/index  — enqueue products, returns 202 immediately.
  - Provides POST /search          — image similarity search.
  - Provides POST /search/text     — text semantic search.
  - Provides GET  /products/{id}/tags
  - Provides GET  /products/queue/depth
"""
import asyncio
import logging

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from app.config import settings
from app.db import close_pool, init_pool
from app.routes.index_route import router as index_router
from app.routes.search_route import router as search_router
from app.routes.text_search_route import router as text_search_router

logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s  %(levelname)-8s  %(name)s  %(message)s",
)
logger = logging.getLogger(__name__)

app = FastAPI(
    title="Image Search Service",
    description=(
        "Visual product search backed by OpenAI CLIP (ViT-B-32, float16) "
        "and PostgreSQL pgvector. Indexing is asynchronous — POST /products/index "
        "returns 202 immediately and a background worker handles the rest."
    ),
    version="3.1.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(index_router)
app.include_router(search_router)
app.include_router(text_search_router)

_worker_task: asyncio.Task | None = None


@app.on_event("startup")
async def startup() -> None:
    global _worker_task

    logger.info("Starting up Image Search Service …")
    await init_pool()
    await _ensure_hnsw_index()

    loop = asyncio.get_running_loop()
    from app.clip_service import clip_search_executor, clip_index_executor, load_model
    from app.tagging_service import warm_tag_cache

    # Step 1: load CLIP model weights
    logger.info("Pre-loading CLIP model …")
    await loop.run_in_executor(clip_search_executor, load_model)
    logger.info("CLIP model loaded.")

    # Step 2: encode tag vocabulary once and cache it.
    # After this, generate_tags() is a pure numpy dot product with no
    # CLIP call and no model lock — indexing no longer blocks search.
    logger.info("Pre-computing tag vocabulary embeddings …")
    await loop.run_in_executor(clip_index_executor, warm_tag_cache)
    logger.info("Tag cache ready.")

    # Step 3: start the background indexing worker
    from app.queue_worker import start_worker
    _worker_task = await start_worker()

    logger.info("Service fully ready. Accepting requests.")


@app.on_event("shutdown")
async def shutdown() -> None:
    global _worker_task
    logger.info("Shutting down …")

    if _worker_task and not _worker_task.done():
        _worker_task.cancel()
        try:
            await _worker_task
        except asyncio.CancelledError:
            pass

    await close_pool()
    logger.info("Shutdown complete.")


async def _ensure_hnsw_index() -> None:
    """Create the HNSW cosine index if it does not already exist. Safe on existing data."""
    from app.db import get_pool
    pool = get_pool()
    async with pool.acquire() as conn:
        exists = await conn.fetchval(
            "SELECT 1 FROM pg_indexes WHERE indexname = 'idx_product_embeddings_hnsw'"
        )
        if not exists:
            logger.info("Creating HNSW index on product_embeddings …")
            await conn.execute(
                """
                CREATE INDEX IF NOT EXISTS idx_product_embeddings_hnsw
                ON product_embeddings
                USING hnsw (embedding vector_cosine_ops)
                WITH (m = 16, ef_construction = 64)
                """
            )
            logger.info("HNSW index created.")
        else:
            logger.info("HNSW index already present.")


@app.get("/health", tags=["Health"])
async def health():
    from app.queue_worker import queue_depth
    return {
        "status": "ok",
        "clip_model": settings.clip_model_name,
        "clip_pretrained": settings.clip_pretrained,
        "embedding_dim": settings.clip_embedding_dim,
        "queue_depth": queue_depth(),
    }


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=False)
