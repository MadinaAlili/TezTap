-- ─────────────────────────────────────────────────────────────────────────────
-- Image Search Service — Database Schema
-- Run this once against your PostgreSQL database before starting the service.
-- ─────────────────────────────────────────────────────────────────────────────

-- 1. Enable pgvector extension (requires pgvector to be installed on the server)
CREATE EXTENSION IF NOT EXISTS vector;

-- 2. Embeddings table
--    product_id  → FK-style reference to your products table (no hard FK here
--                  so the Python service stays independent of your Java schema).
--    embedding   → 512-dimensional CLIP ViT-B-32 vector.
--    indexed_at  → updated on every re-index so you can audit freshness.
CREATE TABLE IF NOT EXISTS product_embeddings (
    id          BIGSERIAL   PRIMARY KEY,
    product_id  BIGINT      NOT NULL,
    embedding   vector(512) NOT NULL,
    indexed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW(),

    CONSTRAINT uq_product_embeddings_product_id UNIQUE (product_id)
);

-- ── Index options ────────────────────────────────────────────────────────────
-- Option A — HNSW (recommended for < ~5 M rows, best recall, fast queries)
--   Works well for dynamic inserts; no need to rebuild.
CREATE INDEX IF NOT EXISTS idx_product_embeddings_hnsw
    ON product_embeddings
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);

-- Option B — IVFFlat (better for very large tables, but needs VACUUM after bulk loads)
-- Uncomment and drop the HNSW index if you prefer IVFFlat:
--
-- CREATE INDEX IF NOT EXISTS idx_product_embeddings_ivfflat
--     ON product_embeddings
--     USING ivfflat (embedding vector_cosine_ops)
--     WITH (lists = 100);
--
-- After a large bulk import run:
--   VACUUM ANALYZE product_embeddings;

-- ── Optional: hard foreign key ───────────────────────────────────────────────
-- If you want a real FK to a products table managed by your Java app, add:
--
--   ALTER TABLE product_embeddings
--       ADD CONSTRAINT fk_product_embeddings_product
--       FOREIGN KEY (product_id) REFERENCES products(id)
--       ON DELETE CASCADE;
--
-- Make sure the referenced table/column exists first.


-- ─────────────────────────────────────────────────────────────────────────────
-- 3. Auto-generated tags table
--    One row per (product_id, tag). Tags are replaced on every re-index.
-- ─────────────────────────────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS product_tags (
    id          BIGSERIAL   PRIMARY KEY,
    product_id  BIGINT      NOT NULL,
    tag         TEXT        NOT NULL,

    CONSTRAINT uq_product_tags_product_tag UNIQUE (product_id, tag)
);

-- Fast lookups: "give me all tags for product X" and "find products with tag Y"
CREATE INDEX IF NOT EXISTS idx_product_tags_product_id ON product_tags (product_id);
CREATE INDEX IF NOT EXISTS idx_product_tags_tag        ON product_tags (tag);

-- ── Optional: cascade-delete tags when embedding is removed ──────────────────
-- Uncomment if you add the FK to product_embeddings above:
--
--   ALTER TABLE product_tags
--       ADD CONSTRAINT fk_product_tags_embedding
--       FOREIGN KEY (product_id) REFERENCES product_embeddings(product_id)
--       ON DELETE CASCADE;
