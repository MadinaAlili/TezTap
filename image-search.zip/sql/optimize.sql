-- =============================================================================
-- optimize.sql — Safe performance migration for the Image Search Service
-- =============================================================================
-- Run this against your existing database. It is fully idempotent:
--   - No tables are dropped or truncated.
--   - No existing rows are modified.
--   - Every statement uses IF NOT EXISTS or checks before acting.
--   - Safe to run multiple times.
--
-- Usage:
--   psql -h <host> -U <user> -d <db> -f optimize.sql
--   -- or inside docker:
--   docker compose exec db psql -U postgres -d image_search -f /optimize.sql
-- =============================================================================


-- -----------------------------------------------------------------------------
-- 1. HNSW index on product_embeddings
--    init.sql already creates this, but if you ran an older version of init.sql
--    that only had an IVFFlat index (or no index at all), this adds it safely.
--    IF NOT EXISTS makes it a no-op if the index already exists.
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_product_embeddings_hnsw
    ON product_embeddings
    USING hnsw (embedding vector_cosine_ops)
    WITH (m = 16, ef_construction = 64);


-- -----------------------------------------------------------------------------
-- 2. Set hnsw.ef_search default for the database
--    ef_search controls how many candidates the HNSW graph explores per query.
--    The PostgreSQL default is 10, which is too low and misses good results.
--    40 is a solid balance of recall and speed.
--    Raise to 80 if you see poor search quality; lower to 20 for max speed.
--
--    This is a database-level default. The Python app also sets it per
--    connection in vector_store.py, so this is just a belt-and-suspenders
--    safeguard (e.g. for direct psql queries or other clients).
--
--    Replace 'image_search' with your actual database name if different.
-- -----------------------------------------------------------------------------
ALTER DATABASE image_search SET hnsw.ef_search = 40;


-- -----------------------------------------------------------------------------
-- 3. Tag indexes
--    init.sql already creates these, but if you have an older schema version
--    without them, this adds them safely.
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_product_tags_product_id ON product_tags (product_id);
CREATE INDEX IF NOT EXISTS idx_product_tags_tag        ON product_tags (tag);


-- -----------------------------------------------------------------------------
-- 4. Index on indexed_at for freshness / audit queries
--    "Which products were indexed in the last 24 hours?"
--    Not critical for search performance, but useful for monitoring.
-- -----------------------------------------------------------------------------
CREATE INDEX IF NOT EXISTS idx_product_embeddings_indexed_at
    ON product_embeddings (indexed_at DESC);


-- -----------------------------------------------------------------------------
-- 5. Update table statistics
--    ANALYZE tells the query planner the current row counts and value
--    distributions. Run after a large bulk import too. This does NOT
--    modify any data — it only reads rows to build statistics.
-- -----------------------------------------------------------------------------
ANALYZE product_embeddings;
ANALYZE product_tags;


-- -----------------------------------------------------------------------------
-- 6. Verify everything looks correct
--    Run these SELECT statements to confirm the migration succeeded.
-- -----------------------------------------------------------------------------

-- Check indexes on product_embeddings:
SELECT
    indexname,
    indexdef
FROM pg_indexes
WHERE tablename = 'product_embeddings'
ORDER BY indexname;

-- Check indexes on product_tags:
SELECT
    indexname,
    indexdef
FROM pg_indexes
WHERE tablename = 'product_tags'
ORDER BY indexname;

-- Check row counts (your existing data should be intact):
SELECT
    'product_embeddings' AS tbl, COUNT(*) AS rows FROM product_embeddings
UNION ALL
SELECT
    'product_tags'       AS tbl, COUNT(*) AS rows FROM product_tags;

-- Check hnsw.ef_search is now set at the database level:
SELECT
    datname,
    unnest(setconfig) AS setting
FROM pg_db_role_setting
JOIN pg_database ON pg_database.oid = setdatabase
WHERE datname = current_database()
  AND unnest(setconfig) LIKE 'hnsw%';
