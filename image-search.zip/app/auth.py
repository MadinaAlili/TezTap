"""
Bearer-token authentication backed by your Java application.

To ENABLE authentication:
  1. Uncomment everything below.
  2. Set JAVA_AUTH_URL in your .env file (e.g. http://my-java-service:8080).
  3. Add `Depends(verify_token)` to any route that should be protected.

Example route usage:
    @router.post("/products/index")
    async def index_products(
        body: IndexRequest,
        _: None = Depends(verify_token),   # ← add this line
    ):
        ...
"""

# from fastapi import Depends, HTTPException, status
# from fastapi.security import HTTPAuthorizationCredentials, HTTPBearer
# import httpx
# from app.config import settings
#
# _bearer = HTTPBearer()
#
#
# async def verify_token(
#     credentials: HTTPAuthorizationCredentials = Depends(_bearer),
# ) -> None:
#     """
#     Validates the Bearer token by calling the Java auth endpoint.
#     Raises HTTP 401 if invalid, HTTP 503 if the auth service is unreachable.
#     """
#     token = credentials.credentials
#     try:
#         async with httpx.AsyncClient(timeout=5.0) as client:
#             response = await client.get(
#                 f"{settings.java_auth_url}/auth/validate",
#                 headers={"Authorization": f"Bearer {token}"},
#             )
#         if response.status_code != 200:
#             raise HTTPException(
#                 status_code=status.HTTP_401_UNAUTHORIZED,
#                 detail="Invalid or expired token.",
#             )
#     except httpx.RequestError as exc:
#         raise HTTPException(
#             status_code=status.HTTP_503_SERVICE_UNAVAILABLE,
#             detail=f"Auth service unreachable: {exc}",
#         )
