"""
CLIP service — optimised for t3.small (2 vCPU, 2 GB RAM).

Performance optimisations
──────────────────────────
1. float32 (NOT float16) on CPU.
   float16 sounds like it saves memory but on CPU it backfires:
   PyTorch has no native float16 compute kernels on x86, so during
   every forward pass it internally upcasts to float32 anyway.
   Peak memory = float16 weights (~150 MB) + float32 compute copy
   (~300 MB) = ~450 MB. Pure float32 = ~300 MB with no duplication.

2. torch.inference_mode() — faster than no_grad(); disables both
   gradient computation and version tracking.

3. Single-crop query encoding — original used 3 crops (3× slower).

4. BytesIO input — encode functions accept raw bytes / BytesIO /
   PIL Image / file path. Callers never write images to disk.

5. Two dedicated ThreadPoolExecutors — clip_search_executor for
   /search routes, clip_index_executor for background indexing.
   Search requests are never queued behind indexing tasks.

6. Pre-warm at startup — load_model() called once at app startup.
"""
import gc
import logging
import threading
from concurrent.futures import ThreadPoolExecutor
from io import BytesIO
from typing import Union

import numpy as np
import open_clip
import torch
from PIL import Image

from app.config import settings

logger = logging.getLogger(__name__)

DEVICE = "cpu"

torch.set_num_threads(2)
torch.set_num_interop_threads(1)

# ── Two dedicated thread pools ────────────────────────────────────────────────
clip_search_executor = ThreadPoolExecutor(
    max_workers=1, thread_name_prefix="clip-search"
)
clip_index_executor = ThreadPoolExecutor(
    max_workers=1, thread_name_prefix="clip-index"
)

# ── Singleton state ───────────────────────────────────────────────────────────
_model      = None
_preprocess = None
_tokenizer  = None
_model_lock = threading.Lock()


# ── Model lifecycle ───────────────────────────────────────────────────────────

def _load_model_locked() -> None:
    """Load the model in float32. Must be called with _model_lock held."""
    global _model, _preprocess, _tokenizer
    if _model is not None:
        return

    logger.info("Loading CLIP %s/%s …", settings.clip_model_name, settings.clip_pretrained)
    model, _, preprocess = open_clip.create_model_and_transforms(
        settings.clip_model_name,
        pretrained=settings.clip_pretrained,
    )
    # float32: on CPU this is optimal — float16 causes internal upcasting
    # during inference, increasing peak RAM rather than reducing it.
    model = model.to(DEVICE).eval().float()

    _model      = model
    _preprocess = preprocess
    _tokenizer  = open_clip.get_tokenizer(settings.clip_model_name)
    logger.info("CLIP ready (float32). Dim=%d", settings.clip_embedding_dim)


def load_model() -> None:
    """Pre-warm: call from app startup so the first request pays no load penalty."""
    with _model_lock:
        _load_model_locked()


def unload_model() -> None:
    """Release the model. Only needed under extreme memory pressure."""
    global _model, _preprocess, _tokenizer
    with _model_lock:
        if _model is None:
            return
        del _model, _preprocess, _tokenizer
        _model = _preprocess = _tokenizer = None
        gc.collect()
        logger.info("CLIP model unloaded.")


# ── Helpers ───────────────────────────────────────────────────────────────────

def _ensure_loaded() -> None:
    global _model
    if _model is None:
        with _model_lock:
            _load_model_locked()


def _normalize(t: torch.Tensor) -> torch.Tensor:
    return t / t.norm(dim=-1, keepdim=True)


def _open_image(src: Union[str, bytes, BytesIO, Image.Image]) -> Image.Image:
    if isinstance(src, Image.Image):
        return src.convert("RGB")
    if isinstance(src, (bytes, bytearray)):
        return Image.open(BytesIO(src)).convert("RGB")
    if isinstance(src, BytesIO):
        src.seek(0)
        return Image.open(src).convert("RGB")
    return Image.open(src).convert("RGB")


# ── Public encode functions ───────────────────────────────────────────────────

def encode_image_batch(sources: list) -> np.ndarray:
    """Encode a batch of images. Returns float32 array (N, embedding_dim)."""
    _ensure_loaded()
    with _model_lock:
        with torch.inference_mode():
            tensors = [_preprocess(_open_image(s)) for s in sources]
            batch   = torch.stack(tensors).to(DEVICE)
            feats   = _model.encode_image(batch)
            feats   = _normalize(feats)
    if settings.clip_unload_after_use:
        unload_model()
    return feats.float().cpu().numpy().astype("float32")


def encode_query_image(src: Union[str, bytes, BytesIO, Image.Image]) -> np.ndarray:
    """Encode a single query image. Returns float32 vector (embedding_dim,)."""
    _ensure_loaded()
    with _model_lock:
        with torch.inference_mode():
            tensor = _preprocess(_open_image(src)).unsqueeze(0).to(DEVICE)
            feat   = _model.encode_image(tensor)
            feat   = _normalize(feat)
    if settings.clip_unload_after_use:
        unload_model()
    return feat.squeeze(0).float().cpu().numpy().astype("float32")


def encode_text(text: str) -> np.ndarray:
    """Encode a text query. Returns float32 vector (embedding_dim,)."""
    _ensure_loaded()
    with _model_lock:
        with torch.inference_mode():
            tokens = _tokenizer([text]).to(DEVICE)
            feat   = _model.encode_text(tokens)
            feat   = _normalize(feat)
    if settings.clip_unload_after_use:
        unload_model()
    return feat.squeeze(0).float().cpu().numpy().astype("float32")


def encode_texts(texts: list) -> np.ndarray:
    """Encode a list of strings. Returns float32 array (N, embedding_dim)."""
    _ensure_loaded()
    with _model_lock:
        with torch.inference_mode():
            tokens = _tokenizer(texts).to(DEVICE)
            feats  = _model.encode_text(tokens)
            feats  = _normalize(feats)
    if settings.clip_unload_after_use:
        unload_model()
    return feats.float().cpu().numpy().astype("float32")
