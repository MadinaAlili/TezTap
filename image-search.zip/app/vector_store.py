"""
pgvector operations: upsert a product embedding and query for nearest neighbours.

Vectors are passed to PostgreSQL as a text literal '[f1,f2,…]' cast to
the pgvector `vector` type — no custom asyncpg codec needed.

hnsw.ef_search = 40 is set per connection before each search query.
This controls the HNSW recall/speed tradeoff:
  - Too low (default 10): fast but misses good results.
  - 40: excellent recall for most catalogue sizes up to ~500k products.
  - 80-100: near-perfect recall, ~2x slower — use if you see poor results.
"""
import logging

import numpy as np

from app.db import get_pool
from app.models import SearchMatch

logger = logging.getLogger(__name__)


def _vec_to_pg(vec: np.ndarray) -> str:
    """Convert a 1-D numpy array to the pgvector text literal '[f,f,…]'."""
    return "[" + ",".join(f"{v:.6f}" for v in vec.tolist()) + "]"


async def upsert_embedding(product_id: int, embedding: np.ndarray) -> None:
    """
    Insert or replace the CLIP embedding for product_id.
    ON CONFLICT … DO UPDATE makes re-indexing idempotent — existing rows
    are updated in place, existing data for other products is untouched.
    """
    pool    = get_pool()
    vec_str = _vec_to_pg(embedding)

    async with pool.acquire() as conn:
        await conn.execute(
            """
            INSERT INTO product_embeddings (product_id, embedding)
            VALUES ($1, $2::vector)
            ON CONFLICT (product_id)
            DO UPDATE SET
                embedding  = EXCLUDED.embedding,
                indexed_at = NOW()
            """,
            product_id,
            vec_str,
        )
    logger.debug("Upserted embedding for product_id=%d", product_id)


async def search_similar(query_vec: np.ndarray, top_k: int) -> list[SearchMatch]:
    """
    Return the top_k most similar products using cosine distance (<=>).
    Cosine similarity = 1 − cosine_distance.
    """
    pool    = get_pool()
    vec_str = _vec_to_pg(query_vec)

    async with pool.acquire() as conn:
        # Set ef_search for this connection before the query.
        # Controls HNSW graph traversal depth: higher = better recall, more CPU.
        await conn.execute("SET hnsw.ef_search = 40")

        rows = await conn.fetch(
            """
            SELECT
                product_id,
                1.0 - (embedding <=> $1::vector) AS similarity
            FROM product_embeddings
            ORDER BY embedding <=> $1::vector
            LIMIT $2
            """,
            vec_str,
            top_k,
        )

    return [
        SearchMatch(
            product_id=row["product_id"],
            similarity=float(row["similarity"]),
            rank=rank,
        )
        for rank, row in enumerate(rows, start=1)
    ]
