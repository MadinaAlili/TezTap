import os
from functools import lru_cache
from pydantic_settings import BaseSettings


class Settings(BaseSettings):
    # ── PostgreSQL ────────────────────────────────────────────────────────────
    # Supports both naming conventions:
    #   - Our names:      POSTGRES_HOST / POSTGRES_DB / POSTGRES_USER / POSTGRES_PASSWORD
    #   - Platform names: DB_HOST / DB_NAME / DB_USER / DB_PASS
    # Whichever set is present in the environment will be used.
    postgres_host:     str = "localhost"
    postgres_port:     int = 5432
    postgres_db:       str = "SDP"
    postgres_user:     str = "postgres"
    postgres_password: str = "admin"

    # Short aliases injected by many hosting platforms (AWS, Railway, Render, etc.)
    db_host: str = ""
    db_name: str = ""
    db_user: str = ""
    db_pass: str = ""

    postgres_min_pool: int = 2
    postgres_max_pool: int = 10

    # ── CLIP model ────────────────────────────────────────────────────────────
    clip_model_name:       str  = "ViT-B-32"
    clip_pretrained:       str  = "openai"
    clip_embedding_dim:    int  = 512
    clip_batch_size:       int  = 8        # kept low to reduce peak RAM

    # Set to true to unload CLIP from RAM after every encode call.
    # Keeps idle RAM near zero but adds ~5 s reload latency per request.
    clip_unload_after_use: bool = False

    # ── File system ───────────────────────────────────────────────────────────
    temp_dir: str = "/tmp/image_search"

    # ── Networking ────────────────────────────────────────────────────────────
    image_download_timeout: int = 20

    # ── Auth (used only when authentication is enabled) ───────────────────────
    java_auth_url: str = "http://localhost:8080"

    class Config:
        env_file          = ".env"
        env_file_encoding = "utf-8"
        case_sensitive    = False
        # Ignore any extra env vars injected by the hosting platform
        extra             = "ignore"

    @property
    def effective_postgres_host(self) -> str:
        return self.db_host or self.postgres_host

    @property
    def effective_postgres_db(self) -> str:
        return self.db_name or self.postgres_db

    @property
    def effective_postgres_user(self) -> str:
        return self.db_user or self.postgres_user

    @property
    def effective_postgres_password(self) -> str:
        return self.db_pass or self.postgres_password


@lru_cache()
def get_settings() -> Settings:
    return Settings()


settings = get_settings()

# Ensure temp directory exists at import time
os.makedirs(settings.temp_dir, exist_ok=True)
