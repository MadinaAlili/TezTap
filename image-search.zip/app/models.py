from decimal import Decimal
from typing import Optional

from pydantic import BaseModel, HttpUrl, field_validator


# ── Inbound DTOs (mirror of Java ProductDTO) ──────────────────────────────────

class ProductDTO(BaseModel):
    """
    Mirrors the Java ProductDTO record:
        record ProductDTO(Long id, String name, BigDecimal originalPrice,
                          BigDecimal discountPrice, BigDecimal discountPercentage,
                          String link, String imageUrl,
                          Long categoryId, Long marketId)
    """
    id: int
    name: str
    original_price: Optional[Decimal] = None
    discount_price: Optional[Decimal] = None
    discount_percentage: Optional[Decimal] = None
    link: Optional[str] = None
    image_url: str
    category_id: Optional[int] = None
    market_id: Optional[int] = None

    @field_validator("image_url")
    @classmethod
    def image_url_must_not_be_empty(cls, v: str) -> str:
        # Normalise whitespace but do NOT raise here — an empty/blank
        # image_url is caught at the route level so the rest of a batch
        # is still processed instead of the whole request returning 422.
        return v.strip() if v else v

    class Config:
        # Accept both camelCase (from Java JSON) and snake_case
        populate_by_name = True
        alias_generator = None


class ProductDTOCamel(ProductDTO):
    """Same as ProductDTO but with camelCase aliases for direct Java JSON mapping."""

    model_config = {
        "populate_by_name": True,
    }

    @classmethod
    def model_validate_camel(cls, data: dict) -> "ProductDTOCamel":
        # Map camelCase Java fields to snake_case Pydantic fields
        mapping = {
            "originalPrice": "original_price",
            "discountPrice": "discount_price",
            "discountPercentage": "discount_percentage",
            "imageUrl": "image_url",
            "categoryId": "category_id",
            "marketId": "market_id",
        }
        normalized = {mapping.get(k, k): v for k, v in data.items()}
        return cls.model_validate(normalized)


# ── Index endpoint ────────────────────────────────────────────────────────────

class IndexRequest(BaseModel):
    """Accepts a single product or a list."""
    products: list[ProductDTO]


class IndexResult(BaseModel):
    product_id: int
    status: str                  # "indexed" | "skipped" | "failed"
    tags: list[str] = []         # auto-generated CLIP tags (empty on failure)
    detail: Optional[str] = None


class IndexResponse(BaseModel):
    indexed: int
    skipped: int
    failed: int
    results: list[IndexResult]


# ── Search endpoint ───────────────────────────────────────────────────────────

class SearchRequest(BaseModel):
    image_base64: str            # base64-encoded image (any common format)
    top_k: int = 5

    @field_validator("top_k")
    @classmethod
    def top_k_range(cls, v: int) -> int:
        if not 1 <= v <= 100:
            raise ValueError("top_k must be between 1 and 100")
        return v


class SearchMatch(BaseModel):
    product_id: int
    similarity: float            # cosine similarity in [0, 1]
    rank: int


class SearchResponse(BaseModel):
    top_k: int
    matches: list[SearchMatch]


# ── Text search endpoint ──────────────────────────────────────────────────────

class TextSearchRequest(BaseModel):
    """
    Send a free-text query (e.g. "red winter jacket", "chocolate cake")
    and the number of results you want back.
    """
    query: str
    top_k: int = 5

    @field_validator("query")
    @classmethod
    def query_must_not_be_empty(cls, v: str) -> str:
        if not v or not v.strip():
            raise ValueError("query must not be empty")
        return v.strip()

    @field_validator("top_k")
    @classmethod
    def top_k_range(cls, v: int) -> int:
        if not 1 <= v <= 100:
            raise ValueError("top_k must be between 1 and 100")
        return v


class TextSearchMatch(BaseModel):
    product_id: int
    similarity: float    # cosine similarity between query text and product image embedding
    rank: int


class TextSearchResponse(BaseModel):
    query: str
    top_k: int
    matches: list[TextSearchMatch]


# ── Tags endpoint ─────────────────────────────────────────────────────────────

class ProductTagsResponse(BaseModel):
    product_id: int
    tags: list[str]
