# Using pgvector Data in Your Java Application

This guide explains how to query the `product_embeddings` table directly from Java, using either **Spring Data JPA** or plain **JDBC**.

---

## Table Structure (quick reference)

```sql
CREATE TABLE product_embeddings (
    id          BIGSERIAL   PRIMARY KEY,
    product_id  BIGINT      NOT NULL UNIQUE,  -- ← your product FK
    embedding   vector(512) NOT NULL,
    indexed_at  TIMESTAMPTZ NOT NULL DEFAULT NOW()
);
```

---

## Option 1 — Query via REST (recommended)

The simplest approach: call the Image Search Service from Java instead of hitting Postgres directly.

```java
// Send a base64-encoded image; get back ranked product IDs.
RestTemplate rest = new RestTemplate();

Map<String, Object> body = Map.of(
    "image_base64", Base64.getEncoder().encodeToString(imageBytes),
    "top_k", 10
);

ResponseEntity<SearchResponse> response = rest.postForEntity(
    "http://image-search-service:8000/search",
    body,
    SearchResponse.class
);

List<SearchMatch> matches = response.getBody().matches();
// matches[0].productId(), matches[0].similarity(), matches[0].rank()
```

---

## Option 2 — Direct JDBC / pgvector-jdbc

Use [pgvector-java](https://github.com/pgvector/pgvector-java) for native type support.

### Maven dependency

```xml
<dependency>
    <groupId>com.pgvector</groupId>
    <artifactId>pgvector</artifactId>
    <version>0.1.6</version>
</dependency>
```

### Register the vector type

```java
import com.pgvector.PGvector;

// Once per connection / data source
try (Connection conn = dataSource.getConnection()) {
    PGvector.addVectorType(conn);
}
```

### Find indexed product IDs

```java
// Check whether a product has been indexed
String sql = "SELECT product_id, indexed_at FROM product_embeddings WHERE product_id = ?";
try (PreparedStatement ps = conn.prepareStatement(sql)) {
    ps.setLong(1, productId);
    ResultSet rs = ps.executeQuery();
    if (rs.next()) {
        System.out.println("Indexed at: " + rs.getTimestamp("indexed_at"));
    }
}
```

### Nearest-neighbour search from Java (if you hold the query vector)

```java
import com.pgvector.PGvector;

float[] queryEmbedding = /* your CLIP embedding */ new float[512];
PGvector vec = new PGvector(queryEmbedding);

String sql = """
    SELECT product_id,
           1.0 - (embedding <=> ?) AS similarity
    FROM   product_embeddings
    ORDER  BY embedding <=> ?
    LIMIT  ?
    """;

try (PreparedStatement ps = conn.prepareStatement(sql)) {
    ps.setObject(1, vec);
    ps.setObject(2, vec);
    ps.setInt(3, topK);

    ResultSet rs = ps.executeQuery();
    while (rs.next()) {
        long   productId  = rs.getLong("product_id");
        double similarity = rs.getDouble("similarity");
        System.out.printf("product_id=%d  similarity=%.4f%n", productId, similarity);
    }
}
```

---

## Option 3 — Spring Data JPA + pgvector

### 1. Add dependencies

```xml
<!-- pgvector JDBC type support -->
<dependency>
    <groupId>com.pgvector</groupId>
    <artifactId>pgvector</artifactId>
    <version>0.1.6</version>
</dependency>
```

### 2. Entity

```java
import jakarta.persistence.*;
import com.pgvector.PGvector;
import java.time.OffsetDateTime;

@Entity
@Table(name = "product_embeddings")
public class ProductEmbedding {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "product_id", nullable = false, unique = true)
    private Long productId;

    // Store as String; convert manually when needed
    @Column(name = "embedding", columnDefinition = "vector(512)")
    private String embedding;

    @Column(name = "indexed_at")
    private OffsetDateTime indexedAt;

    // getters / setters …
}
```

### 3. Repository with native nearest-neighbour query

```java
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import java.util.List;

public interface ProductEmbeddingRepository
        extends JpaRepository<ProductEmbedding, Long> {

    /**
     * Returns the product_ids of the top-k nearest neighbours.
     * Pass the query vector as a pgvector text literal, e.g. "[0.1,0.2,…]".
     */
    @Query(
        value = """
            SELECT product_id
            FROM   product_embeddings
            ORDER  BY embedding <=> CAST(:vec AS vector)
            LIMIT  :topK
            """,
        nativeQuery = true
    )
    List<Long> findTopKSimilar(
        @Param("vec")  String vec,
        @Param("topK") int topK
    );
}
```

### 4. Service usage

```java
@Service
@RequiredArgsConstructor
public class VisualSearchService {

    private final ProductEmbeddingRepository repo;

    public List<Long> findSimilarProducts(float[] queryEmbedding, int topK) {
        // Convert float[] to pgvector text literal
        StringBuilder sb = new StringBuilder("[");
        for (int i = 0; i < queryEmbedding.length; i++) {
            if (i > 0) sb.append(',');
            sb.append(queryEmbedding[i]);
        }
        sb.append(']');
        return repo.findTopKSimilar(sb.toString(), topK);
    }
}
```

---

## Useful SQL Snippets

```sql
-- Count indexed products
SELECT COUNT(*) FROM product_embeddings;

-- Check specific products
SELECT product_id, indexed_at
FROM   product_embeddings
WHERE  product_id IN (1, 2, 3);

-- Delete a product's embedding (e.g. after product deletion)
DELETE FROM product_embeddings WHERE product_id = 42;

-- Find products indexed in the last 24 hours
SELECT product_id, indexed_at
FROM   product_embeddings
WHERE  indexed_at > NOW() - INTERVAL '24 hours'
ORDER  BY indexed_at DESC;

-- Manual nearest-neighbour search (cosine similarity)
SELECT product_id,
       1.0 - (embedding <=> '[0.1,0.2, …512 values… ]'::vector) AS similarity
FROM   product_embeddings
ORDER  BY embedding <=> '[0.1,0.2, …512 values… ]'::vector
LIMIT  10;
```

---

## Notes

- **Cosine similarity** is `1 − cosine_distance`. The `<=>` operator in pgvector computes cosine distance, so `1 - (a <=> b)` gives cosine similarity.
- The HNSW index (created by `init.sql`) makes ANN queries fast but approximate. For exact results remove the index and pgvector will do a full sequential scan.
- If you add the optional hard FK (`REFERENCES products(id) ON DELETE CASCADE`), deleting a product row from your Java-managed table will automatically remove the embedding.
