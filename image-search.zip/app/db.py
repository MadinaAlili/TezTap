"""
Async PostgreSQL connection pool backed by asyncpg.
Call init_pool() at app startup and close_pool() at shutdown.
"""
import logging
from typing import Optional

import asyncpg

from app.config import settings

logger = logging.getLogger(__name__)

_pool: Optional[asyncpg.Pool] = None


async def init_pool() -> None:
    global _pool
    dsn = (
        f"postgresql://{settings.effective_postgres_user}:{settings.effective_postgres_password}"
        f"@{settings.effective_postgres_host}:{settings.postgres_port}/{settings.effective_postgres_db}"
    )
    logger.info("Connecting to PostgreSQL at %s:%d/%s …",
                settings.effective_postgres_host, settings.postgres_port, settings.effective_postgres_db)
    _pool = await asyncpg.create_pool(
        dsn=dsn,
        min_size=settings.postgres_min_pool,
        max_size=settings.postgres_max_pool,
    )
    logger.info("PostgreSQL pool ready (min=%d, max=%d).",
                settings.postgres_min_pool, settings.postgres_max_pool)


async def close_pool() -> None:
    global _pool
    if _pool:
        await _pool.close()
        _pool = None
        logger.info("PostgreSQL pool closed.")


def get_pool() -> asyncpg.Pool:
    if _pool is None:
        raise RuntimeError("Database pool is not initialised. Call init_pool() first.")
    return _pool
