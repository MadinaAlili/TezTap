"""
Auto-tagging service — assigns descriptive tags to product images using
CLIP zero-shot classification.

How it works:
  1. At startup, encode all candidate tag strings in small batches and
     cache the result as a (V, D) float32 numpy array.
  2. For each product image, compute cosine similarity between the image
     embedding and every cached tag vector — pure numpy dot product,
     no CLIP call, no model lock.
  3. Keep tags that exceed the confidence threshold.

Memory note:
  Encoding all 189 tags in one shot creates large intermediate transformer
  activations that can OOM a 1.5 GB container. Batching keeps peak
  activation memory proportional to VOCAB_ENCODE_BATCH_SIZE, not V.
"""
import logging
import threading
from typing import Optional

import numpy as np

logger = logging.getLogger(__name__)

# How many tag strings to encode in a single CLIP forward pass during
# cache warming. Smaller = lower peak RAM, more passes. 16 is safe for
# a 1.5 GB container; raise to 32 if you have more headroom.
VOCAB_ENCODE_BATCH_SIZE = 16

TAG_VOCABULARY: list[str] = [
    # ── Food & drink ──────────────────────────────────────────────────────────
    "bread", "cake", "cookie", "pastry", "chocolate", "candy", "snack",
    "chips", "cracker", "cereal", "rice", "pasta", "noodle", "flour",
    "sugar", "salt", "spice", "sauce", "oil", "vinegar", "honey",
    "jam", "butter", "cheese", "milk", "yogurt", "egg", "meat", "chicken",
    "fish", "seafood", "fruit", "vegetable", "frozen food", "canned food",
    "coffee", "tea", "juice", "water", "soda", "alcohol", "wine", "beer",
    "baby food", "protein powder", "supplement",

    # ── Personal care & beauty ────────────────────────────────────────────────
    "shampoo", "conditioner", "soap", "body wash", "lotion", "cream",
    "sunscreen", "deodorant", "perfume", "cologne", "toothpaste", "toothbrush",
    "razor", "face wash", "moisturizer", "serum", "makeup", "lipstick",
    "mascara", "foundation", "nail polish", "hair dye", "hair tool",

    # ── Clothing & accessories ────────────────────────────────────────────────
    "shirt", "t-shirt", "blouse", "jacket", "coat", "dress", "skirt",
    "pants", "jeans", "shorts", "underwear", "socks", "shoes", "sneakers",
    "boots", "sandals", "hat", "cap", "scarf", "gloves", "belt", "bag",
    "backpack", "wallet", "sunglasses", "watch", "jewelry", "ring",
    "necklace", "earrings", "bracelet",

    # ── Electronics & accessories ─────────────────────────────────────────────
    "phone", "smartphone", "tablet", "laptop", "computer", "monitor",
    "keyboard", "mouse", "headphones", "earbuds", "speaker", "camera",
    "television", "remote control", "charger", "cable", "battery",
    "power bank", "smart watch", "gaming", "controller",

    # ── Home & kitchen ────────────────────────────────────────────────────────
    "pan", "pot", "knife", "cutting board", "plate", "bowl", "cup", "mug",
    "glass", "bottle", "container", "blender", "toaster", "coffee maker",
    "cleaning product", "detergent", "sponge", "mop", "candle", "lamp",
    "pillow", "blanket", "towel", "curtain", "furniture",

    # ── Health & wellness ─────────────────────────────────────────────────────
    "medicine", "vitamin", "bandage", "thermometer", "mask", "glove",
    "fitness equipment", "yoga mat", "water bottle",

    # ── Colours ───────────────────────────────────────────────────────────────
    "red", "blue", "green", "yellow", "orange", "purple", "pink",
    "black", "white", "grey", "brown", "gold", "silver", "multicolor",

    # ── Visual / packaging descriptors ───────────────────────────────────────
    "round", "square", "bottle", "box", "bag", "tube", "jar", "can",
    "small", "large", "transparent", "glossy", "matte", "wooden", "metal",
    "plastic", "glass container", "eco-friendly", "organic", "natural",
]

_tag_embeddings: Optional[np.ndarray] = None
_cache_lock = threading.Lock()

DEFAULT_THRESHOLD: float = 0.22
MAX_TAGS: int = 15


def warm_tag_cache(vocabulary: Optional[list[str]] = None) -> None:
    """
    Encode all tag strings in small batches and cache the result.

    Batching keeps peak transformer activation memory proportional to
    VOCAB_ENCODE_BATCH_SIZE instead of the full vocabulary size, which
    prevents OOM on memory-constrained containers (mem_limit: 1500m).

    Call from app startup AFTER load_model(), inside clip_index_executor.
    Safe to call multiple times — subsequent calls are no-ops.
    """
    global _tag_embeddings
    with _cache_lock:
        if _tag_embeddings is not None:
            return

        from app.clip_service import encode_texts
        vocab = vocabulary or TAG_VOCABULARY
        logger.info(
            "Warming tag embedding cache: %d tags in batches of %d …",
            len(vocab), VOCAB_ENCODE_BATCH_SIZE,
        )

        chunks = []
        for i in range(0, len(vocab), VOCAB_ENCODE_BATCH_SIZE):
            batch = vocab[i : i + VOCAB_ENCODE_BATCH_SIZE]
            chunks.append(encode_texts(batch))   # shape (batch, D)

        _tag_embeddings = np.vstack(chunks).astype("float32")
        logger.info("Tag cache ready. Shape: %s", _tag_embeddings.shape)


def generate_tags(
    image_embedding: np.ndarray,
    vocabulary: Optional[list[str]] = None,
    threshold: float = DEFAULT_THRESHOLD,
    max_tags: int = MAX_TAGS,
) -> list[str]:
    """
    Given a pre-computed image embedding, return a list of descriptive tags.

    Uses the cached tag embeddings — pure numpy dot product, no CLIP call,
    no model lock, runs in ~0.1 ms regardless of vocabulary size.
    """
    global _tag_embeddings
    vocab = vocabulary or TAG_VOCABULARY

    if _tag_embeddings is not None and vocabulary is None:
        text_embeddings = _tag_embeddings
    else:
        logger.warning("Tag cache not warm — encoding live. Call warm_tag_cache() at startup.")
        from app.clip_service import encode_texts
        text_embeddings = encode_texts(vocab)

    scores = text_embeddings @ image_embedding   # shape (V,), pure numpy

    accepted = [
        (vocab[i], float(scores[i]))
        for i in range(len(vocab))
        if scores[i] >= threshold
    ]
    accepted.sort(key=lambda x: x[1], reverse=True)
    tags = [tag for tag, _ in accepted[:max_tags]]

    logger.debug("Generated %d tags: %s", len(tags), tags)
    return tags
