"""
Tag store — persists and retrieves auto-generated product tags.

Schema:
    product_tags (product_id BIGINT, tag TEXT, score FLOAT)

Tags are deleted and re-inserted on every re-index (idempotent).
"""
import logging

from app.db import get_pool

logger = logging.getLogger(__name__)


async def upsert_tags(product_id: int, tags: list[str]) -> None:
    """
    Replace all tags for *product_id* with the new list.
    Using DELETE + INSERT inside a transaction keeps it idempotent.
    """
    pool = get_pool()
    async with pool.acquire() as conn:
        async with conn.transaction():
            await conn.execute(
                "DELETE FROM product_tags WHERE product_id = $1",
                product_id,
            )
            if tags:
                await conn.executemany(
                    """
                    INSERT INTO product_tags (product_id, tag)
                    VALUES ($1, $2)
                    """,
                    [(product_id, tag) for tag in tags],
                )
    logger.debug("Stored %d tags for product_id=%d", len(tags), product_id)


async def get_tags(product_id: int) -> list[str]:
    """Return all tags for a single product, in insertion order."""
    pool = get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            "SELECT tag FROM product_tags WHERE product_id = $1 ORDER BY id",
            product_id,
        )
    return [row["tag"] for row in rows]


async def search_by_tags(query_tags: list[str], top_k: int) -> list[dict]:
    """
    Keyword-based fallback: return products whose stored tags overlap
    with *query_tags*, ranked by number of matching tags (descending).

    This is used as a complement to the CLIP semantic search.
    """
    pool = get_pool()
    async with pool.acquire() as conn:
        rows = await conn.fetch(
            """
            SELECT
                product_id,
                COUNT(*) AS match_count
            FROM product_tags
            WHERE tag = ANY($1::text[])
            GROUP BY product_id
            ORDER BY match_count DESC
            LIMIT $2
            """,
            query_tags,
            top_k,
        )
    return [{"product_id": row["product_id"], "match_count": int(row["match_count"])}
            for row in rows]
