"""
Background indexing queue worker.

Architecture
────────────
                  POST /products/index
                         │
                         ▼
                  asyncio.Queue          ← products enqueued here, 202 returned immediately
                         │
                         ▼
                  _worker() loop         ← single async task, runs forever
                         │
               ┌─────────┴──────────┐
               │  drain up to        │
               │  clip_batch_size    │
               │  items from queue   │
               └─────────┬──────────┘
                         │
               ┌─────────┴──────────┐
               │  download batch     │  ← global semaphore: max 20 concurrent
               │  concurrently       │    across ALL requests, not per-request
               └─────────┬──────────┘
                         │
               ┌─────────┴──────────┐
               │  CLIP encode        │  ← clip_index_executor, one batch at a time
               └─────────┬──────────┘
                         │
               ┌─────────┴──────────┐
               │  upsert embedding   │
               │  generate tags      │
               │  upsert tags        │
               └─────────────────────┘

Why a single worker?
  - CLIP already saturates both CPUs per encode call via torch threads.
  - Running two workers would cause lock contention on _model_lock with no
    throughput gain and higher peak RAM.
  - A queue naturally absorbs request bursts — Java fires requests fast,
    the worker drains them at a sustainable pace.

Queue capacity
  - Unbounded by default.  If your Java service sends tens of thousands of
    products in a short burst you may want to cap it:
      _queue: asyncio.Queue = asyncio.Queue(maxsize=50_000)
    When full, enqueue() will raise QueueFull which the route catches and
    returns 503 so Java can retry later.
"""
import asyncio
import logging

import numpy as np
import httpx

from app.clip_service import clip_index_executor, encode_image_batch
from app.config import settings
from app.models import ProductDTO
from app.tag_store import upsert_tags
from app.tagging_service import generate_tags
from app.vector_store import upsert_embedding

logger = logging.getLogger(__name__)

# ── Queue ─────────────────────────────────────────────────────────────────────
# Holds individual ProductDTO items.  Unbounded — Java can enqueue freely.
# To cap memory during extreme bursts set maxsize= e.g. 100_000.
_queue: asyncio.Queue = asyncio.Queue()

# ── Global download semaphore ─────────────────────────────────────────────────
# Shared across ALL concurrent requests.  No matter how many index requests
# arrive simultaneously, only MAX_CONCURRENT_DOWNLOADS image fetches run at once.
MAX_CONCURRENT_DOWNLOADS = 20
_download_sem: asyncio.Semaphore | None = None   # created in start_worker()

# httpx client config
_HTTPX_TIMEOUT = httpx.Timeout(
    connect=10.0,
    read=settings.image_download_timeout,
    write=10.0,
    pool=5.0,
)
_HTTPX_LIMITS = httpx.Limits(
    max_connections=MAX_CONCURRENT_DOWNLOADS,
    max_keepalive_connections=MAX_CONCURRENT_DOWNLOADS,
)


# ── Public API ────────────────────────────────────────────────────────────────

def enqueue(products: list[ProductDTO]) -> int:
    """
    Add products to the processing queue.
    Returns the queue size after enqueueing.
    Non-blocking — never awaits.
    """
    for p in products:
        _queue.put_nowait(p)
    size = _queue.qsize()
    logger.info("Enqueued %d products. Queue depth: %d", len(products), size)
    return size


def queue_depth() -> int:
    return _queue.qsize()


async def start_worker() -> asyncio.Task:
    """
    Start the background worker task.  Call once from app startup.
    Returns the Task so the caller can cancel it on shutdown.
    """
    global _download_sem
    _download_sem = asyncio.Semaphore(MAX_CONCURRENT_DOWNLOADS)
    task = asyncio.create_task(_worker(), name="indexing-worker")
    logger.info("Background indexing worker started.")
    return task


# ── Internal helpers ──────────────────────────────────────────────────────────

async def _download(client: httpx.AsyncClient, product: ProductDTO) -> tuple[ProductDTO, bytes | None]:
    """Download one image under the global semaphore. Returns (product, bytes|None)."""
    assert _download_sem is not None
    async with _download_sem:
        try:
            response = await client.get(product.image_url, follow_redirects=True)
            response.raise_for_status()
            return product, response.content
        except Exception as exc:
            logger.warning(
                "Download failed for product_id=%d url=%s: %s",
                product.id, product.image_url, repr(exc),
            )
            return product, None


async def _process_batch(batch: list[ProductDTO]) -> None:
    """Download → encode → upsert a list of products."""
    if not batch:
        return

    # ── Download all images concurrently (global semaphore caps total) ────────
    async with httpx.AsyncClient(timeout=_HTTPX_TIMEOUT, limits=_HTTPX_LIMITS) as client:
        results = await asyncio.gather(
            *[_download(client, p) for p in batch],
            return_exceptions=False,   # exceptions handled inside _download
        )

    ready_products = [p for p, b in results if b is not None]
    ready_bytes    = [b for p, b in results if b is not None]

    if not ready_products:
        logger.warning("Entire batch of %d products failed to download.", len(batch))
        return

    # ── CLIP encode ───────────────────────────────────────────────────────────
    loop = asyncio.get_running_loop()
    try:
        embeddings = await loop.run_in_executor(
            clip_index_executor,
            encode_image_batch,
            ready_bytes,
        )
    except Exception as exc:
        logger.error("CLIP encoding failed for batch of %d: %s", len(ready_products), repr(exc), exc_info=True)
        return
    finally:
        del ready_bytes   # free image RAM immediately

    # ── Upsert embeddings + tags ──────────────────────────────────────────────
    for product, raw_embedding in zip(ready_products, embeddings):
        embedding = np.ascontiguousarray(raw_embedding, dtype=np.float32)

        try:
            await upsert_embedding(product.id, embedding)
        except Exception as exc:
            logger.error("Embedding upsert failed for product_id=%d: %s", product.id, repr(exc), exc_info=True)
            continue

        try:
            tags = await loop.run_in_executor(clip_index_executor, generate_tags, embedding)
            await upsert_tags(product.id, tags)
        except Exception as exc:
            logger.warning("Tag step failed for product_id=%d (embedding saved): %s", product.id, repr(exc), exc_info=True)
            continue

        logger.info("Indexed product_id=%d  tags=%s", product.id, tags)

    del embeddings


# ── Worker loop ───────────────────────────────────────────────────────────────

async def _worker() -> None:
    """
    Runs forever.  Pulls up to clip_batch_size items from the queue,
    processes them as a batch, then loops.

    Batching logic:
      1. Block on the first item so the worker sleeps when the queue is empty.
      2. Drain additional items without blocking, up to clip_batch_size.
      3. Process the batch.
      4. Repeat.

    This means items that arrive close together are grouped into one CLIP
    encode call (much more efficient than one encode per product).
    """
    logger.info("Indexing worker loop running.")
    while True:
        batch: list[ProductDTO] = []

        # Block until at least one item is available
        try:
            first = await _queue.get()
            batch.append(first)
        except asyncio.CancelledError:
            logger.info("Indexing worker cancelled.")
            return

        # Drain up to clip_batch_size - 1 more items without waiting
        while len(batch) < settings.clip_batch_size:
            try:
                batch.append(_queue.get_nowait())
            except asyncio.QueueEmpty:
                break

        logger.debug("Worker picked up batch of %d (queue remaining: %d)", len(batch), _queue.qsize())

        try:
            await _process_batch(batch)
        except Exception as exc:
            # Should never reach here — _process_batch handles its own errors.
            # Belt-and-suspenders so the worker never dies on an unexpected exception.
            logger.error("Unexpected error in _process_batch: %s", repr(exc), exc_info=True)
        finally:
            # Mark all items done regardless of success/failure
            for _ in batch:
                _queue.task_done()
