"""
Search route — POST /search

Uses clip_search_executor (dedicated to search) so a running indexing
batch never blocks an incoming search request beyond one lock cycle.

Images are decoded into BytesIO (in RAM) — no temp file is written to disk.
This preserves the original intent of no persistent image storage while
also avoiding the disk I/O latency of the original temp-file approach.
"""
import asyncio
import base64
import binascii
import logging
from io import BytesIO

from fastapi import APIRouter, HTTPException, status

from app.clip_service import clip_search_executor, encode_query_image
from app.models import SearchRequest, SearchResponse
from app.vector_store import search_similar

# from app.auth import verify_token

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Search"])


@router.post(
    "/search",
    response_model=SearchResponse,
    summary="Search for similar products by image",
    description=(
        "Send a base64-encoded image and top_k. "
        "Returns product_ids ranked by cosine similarity."
    ),
)
async def search_by_image(
    body: SearchRequest,
    # _: None = Depends(verify_token),
):
    # Decode base64 → in-memory bytes (no disk I/O, no persistent storage)
    try:
        image_bytes = base64.b64decode(body.image_base64, validate=True)
    except (binascii.Error, ValueError) as exc:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail=f"Invalid base64 image data: {exc}",
        )

    loop = asyncio.get_running_loop()

    # Run CLIP encode in the dedicated search executor.
    # Will wait for the model lock if indexing is in progress, but will
    # NOT queue behind other pending indexing tasks.
    try:
        query_vec = await loop.run_in_executor(
            clip_search_executor,
            encode_query_image,
            BytesIO(image_bytes),
        )
    except Exception as exc:
        logger.error("CLIP query encoding failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Image encoding failed: {exc}",
        )

    try:
        matches = await search_similar(query_vec, body.top_k)
    except Exception as exc:
        logger.error("pgvector search failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Vector search failed: {exc}",
        )

    logger.info("Search returned %d matches (top_k=%d)", len(matches), body.top_k)
    return SearchResponse(top_k=body.top_k, matches=matches)
