"""
Text search route — POST /search/text and GET /products/{id}/tags

Uses clip_search_executor so text searches are never queued behind
indexing tasks.
"""
import asyncio
import logging

from fastapi import APIRouter, HTTPException, Path, status

from app.clip_service import clip_search_executor, encode_text
from app.models import (
    ProductTagsResponse,
    TextSearchMatch,
    TextSearchRequest,
    TextSearchResponse,
)
from app.tag_store import get_tags, search_by_tags
from app.vector_store import search_similar

# from app.auth import verify_token

logger = logging.getLogger(__name__)
router = APIRouter(tags=["Text Search"])


@router.post(
    "/search/text",
    response_model=TextSearchResponse,
    summary="Search for products by text query",
    description=(
        "Send a free-text query (e.g. 'red winter jacket') and top_k. "
        "Uses CLIP text encoder for semantic matching against product image "
        "embeddings, with tag keyword results merged in as a secondary signal."
    ),
)
async def text_search(
    body: TextSearchRequest,
    # _: None = Depends(verify_token),
):
    loop = asyncio.get_running_loop()

    # Encode query text — uses search executor, never blocks on indexing queue
    try:
        query_vec = await loop.run_in_executor(
            clip_search_executor,
            encode_text,
            body.query,
        )
    except Exception as exc:
        logger.error("CLIP text encoding failed for query '%s': %s", body.query, exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Text encoding failed: {exc}",
        )

    try:
        clip_matches = await search_similar(query_vec, body.top_k)
    except Exception as exc:
        logger.error("pgvector text search failed: %s", exc)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Vector search failed: {exc}",
        )

    seen_ids = {m.product_id for m in clip_matches}

    # Tag keyword fallback
    query_tokens = [w.lower() for w in body.query.split() if len(w) >= 2]
    tag_extras: list[TextSearchMatch] = []

    if query_tokens:
        try:
            tag_rows = await search_by_tags(query_tokens, body.top_k)
            for row in tag_rows:
                pid = row["product_id"]
                if pid not in seen_ids:
                    synthetic_sim = min(0.5, row["match_count"] * 0.1)
                    tag_extras.append(TextSearchMatch(
                        product_id=pid, similarity=synthetic_sim, rank=0,
                    ))
                    seen_ids.add(pid)
        except Exception as exc:
            logger.warning("Tag keyword fallback failed: %s", exc)

    all_matches = [
        TextSearchMatch(product_id=m.product_id, similarity=m.similarity, rank=0)
        for m in clip_matches
    ] + tag_extras

    all_matches.sort(key=lambda m: m.similarity, reverse=True)

    final = [
        TextSearchMatch(product_id=m.product_id, similarity=m.similarity, rank=rank)
        for rank, m in enumerate(all_matches[: body.top_k], start=1)
    ]

    logger.info(
        "Text search '%s' → %d matches (%d CLIP, %d tag extras)",
        body.query, len(final), len(clip_matches), len(tag_extras),
    )
    return TextSearchResponse(query=body.query, top_k=body.top_k, matches=final)


@router.get(
    "/products/{product_id}/tags",
    response_model=ProductTagsResponse,
    summary="Get auto-generated tags for a product",
)
async def get_product_tags(
    product_id: int = Path(..., description="The product ID"),
    # _: None = Depends(verify_token),
):
    try:
        tags = await get_tags(product_id)
    except Exception as exc:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=str(exc),
        )
    return ProductTagsResponse(product_id=product_id, tags=tags)
