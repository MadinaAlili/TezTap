"""
Index route — POST /products/index

Immediately enqueues products for background processing and returns
202 Accepted.  The caller (Java service) does not wait for encoding
or DB writes to complete.

The actual work — download, CLIP encode, pgvector upsert, tag generation —
is handled by the background worker in queue_worker.py.

Products with a missing/blank image_url are silently skipped and reported
in the response rather than rejecting the entire batch with 422.
"""
import logging
from typing import Union

from fastapi import APIRouter, HTTPException, status
from fastapi.responses import JSONResponse

from app.models import IndexRequest, ProductDTO
from app.queue_worker import enqueue, queue_depth

# from app.auth import verify_token

logger = logging.getLogger(__name__)
router = APIRouter(prefix="/products", tags=["Indexing"])


@router.post(
    "/index",
    status_code=status.HTTP_202_ACCEPTED,
    summary="Enqueue product images for background indexing",
    description=(
        "Accepts one or more ProductDTOs and immediately returns 202 Accepted. "
        "Encoding and storage happen asynchronously — the caller does not wait. "
        "Products with a missing or blank image_url are skipped and reported. "
        "Check GET /queue/depth to monitor backlog."
    ),
)
async def index_products(
    body: Union[ProductDTO, IndexRequest],
    # _: None = Depends(verify_token),
):
    raw_products: list[ProductDTO] = (
        [body] if isinstance(body, ProductDTO) else body.products
    )

    if not raw_products:
        raise HTTPException(
            status_code=status.HTTP_422_UNPROCESSABLE_ENTITY,
            detail="No products provided.",
        )

    # Split into valid (has a non-blank image_url) and invalid
    valid: list[ProductDTO] = []
    skipped: list[dict] = []

    for p in raw_products:
        if p.image_url and p.image_url.strip():
            valid.append(p)
        else:
            skipped.append({"product_id": p.id, "reason": "image_url is empty or blank"})
            logger.warning("Skipping product_id=%d — image_url is empty.", p.id)

    if skipped:
        logger.info(
            "Skipped %d product(s) with missing image_url out of %d submitted.",
            len(skipped), len(raw_products),
        )

    depth = enqueue(valid) if valid else queue_depth()

    return JSONResponse(
        status_code=status.HTTP_202_ACCEPTED,
        content={
            "accepted": len(valid),
            "skipped": len(skipped),
            "skipped_products": skipped,
            "queue_depth": depth,
        },
    )


@router.get(
    "/queue/depth",
    summary="Current indexing queue depth",
    description="Returns the number of products currently waiting to be indexed.",
    tags=["Indexing"],
)
async def get_queue_depth():
    return {"queue_depth": queue_depth()}
